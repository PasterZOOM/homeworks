import React from 'react'

function AlternativeMessage() {
    return (
        <div>

        </div>
    )
}

export default AlternativeMessage
